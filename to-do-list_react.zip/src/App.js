import React from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import Main from './components/Main';
import './App.scss';
import EditForm from './components/EditForm'

const App = () => {

  return (
    <Routes>
      <Route path="/" element={<Main />} />
      <Route path='/edit:id' element={<EditForm />} />
    </Routes>
  );
}

export default App;
